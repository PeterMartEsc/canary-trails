export interface UsuarioLoginDto {
  nombre: string;
  password: string;
}
