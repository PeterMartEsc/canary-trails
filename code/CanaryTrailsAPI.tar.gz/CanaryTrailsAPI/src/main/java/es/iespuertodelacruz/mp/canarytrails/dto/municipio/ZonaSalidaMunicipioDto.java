package es.iespuertodelacruz.mp.canarytrails.dto.municipio;

public record ZonaSalidaMunicipioDto(
        Integer id,
        String nombre
) {
}
